-- ============================================================
-- src/version.lua -- Versión instalada y endpoint de actualizaciones.
-- ============================================================

return {
    version = "5.6.1",
    url = "https://raw.githubusercontent.com/VotiveRoom/OperacionVIP/main/updates/version.json",
}
